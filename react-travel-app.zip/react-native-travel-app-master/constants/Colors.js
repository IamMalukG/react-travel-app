export default {
  primary: "#0038FB"
};
